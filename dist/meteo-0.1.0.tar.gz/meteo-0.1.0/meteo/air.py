

# constants describing air

cp_d  = 1.006 # isobaric heat capacity of dry air
