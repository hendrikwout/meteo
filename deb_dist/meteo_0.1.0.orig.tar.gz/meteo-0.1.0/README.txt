===========
meteo
===========


Meteo is a library in development to work with meteorological data. It
currently has procedures for moisture variable conversions between relative
humidity, mixing ratio and specific humidity::

    #!/usr/bin/env python

    from meteo import *

    # calculate saturation pressure
    print(esat(282.15))





A Section
=========


A Sub-Section
-------------





