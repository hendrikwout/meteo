
G = 9.81 # gravitational accelleration ms^-2
krm = 0.40 # von Kàrmàn constant

