#!/usr/bin/python
# Filename: radiation.py

# Description:
# radiation properties of the surface and the air 

sbcst = 5.670*10.0**(-8)
